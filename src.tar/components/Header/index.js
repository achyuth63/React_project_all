import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="nav-content">
      <img
        src="https://res.cloudinary.com/des7uyibo/image/upload/c_scale,h_22,q_100,w_22/v1612513736/logo_1_riutsp.svg "
        className="website-logo"
        alt="logo"
      />
      <ul className="nav-menu">
        <li>
          <a
            href="https://www.linkedin.com/in/achyuth-reddy-b85256170/"
            target="blank"
          >
            <img
              className="social-network-img"
              src="https://assets.ccbp.in/frontend/react-js/projects-linkedin-img.png"
              alt="Linked In"
            />
          </a>
        </li>
        <li>
          <a href="https://github.com/achyuth63?tab=repositories">
            <img
              className="social-network-img"
              src="https://assets.ccbp.in/frontend/react-js/projects-github-img.png"
              alt="Git Hub"
            />
          </a>
        </li>
        <li>
          <a href="https://learning.ccbp.in/">
            <img
              className="social-network-img"
              src="https://res.cloudinary.com/des7uyibo/image/upload/v1605170763/5f383a4d6a6ea77270c43c01_Nxtwave_256x256_1_v1tqsr.png"
              alt="NxtWave"
            />
          </a>
        </li>

        <li>
          <a href="https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox?compose=GTvVlcSBpRhPdqlrjNXpjtlHtnmhgjSLRpznqGHXZqQKGThQLkRCzcdqpnWdmLgWgHWKchlBwFzMP">
            <img
              className="social-network-img"
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTthOLoCyESvwudCMLspDFJppiMLbKcFv_nfw&usqp=CAU"
              alt="gmail"
            />
          </a>
        </li>
      </ul>
    </div>
  </nav>
)

export default Header
